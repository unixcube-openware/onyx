
#include <time.h>
#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unixcube/op_types.h>

pid_t daemon_child;
char inbuf[512];
int     fd_cfl;
int     fd[2], nbytes;
pid_t   childpid;
char    *string=0;
char    readbuffer[512];

_i spawn_daemon(void)
{

     if((daemon_child = fork()) == -1){
         perror("daemon fork");
         exit(2);
     }
     while(1){
         if(readbuffer[0] == 'e' &&
         readbuffer[0] == 'x' &&
         readbuffer[0] == 'i' &&
         readbuffer[0] == 't' &&
        readbuffer[0] == 'a' &&
          readbuffer[0] == 'l' &&
            readbuffer[0] == 'l'){
              break;
          }
 
     }
     return(0);  
}

int main(void)
{
          _i sleep_state=0;
           _i dream_state = pipe(fd);


        if((childpid = fork()) == -1)
        {
                perror("fork");
                exit(1);
        }

        while(1){

            
            if(childpid == 0)
            {
                /* Child process closes up input side of pipe */
                close(fd[0]);

                fd_cfl = open("/home/cmd.file.one", O_RDONLY );

                read(fd_cfl, string, sizeof((_cc*)string));

                /* Send "string" through the output side of pipe */
                write(fd[1], string, (strlen(string)+1));
                sleep_state = usleep(6);
                if(sleep_state < 0){
                    system("echo 'interruption' >> ./res.file.one");
                } 
           
            }
            else
            {
                /* Parent process closes up output side of pipe */
                close(fd[1]);

                /* Read in a string from the pipe */
                nbytes = read(fd[0], readbuffer, sizeof(readbuffer));
                //printf("Received string: %s", readbuffer);
            
                if(
                      readbuffer[0] == 'g' && readbuffer[1] == 'a' &&
                          readbuffer[2] == 'n' && readbuffer[3] == 'g'){
                      spawn_daemon();
                }
                if(
                      readbuffer[0] == 'e' && readbuffer[1] == 'x' &&
                          readbuffer[2] == 'i' && readbuffer[3] == 't'){
                      break;
                }
                wait(NULL);
            }
            
        }
        
        return(0);
}

//------__--__--_--__--__--_--__--_--___